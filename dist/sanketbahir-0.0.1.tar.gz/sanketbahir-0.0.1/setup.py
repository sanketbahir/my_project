from setuptools import setup, find_packages
import codecs
import os

setup( 
	name='sanketbahir', 
	version='0.0.1', 
	description='A sample Python package', 
	author='Sanket Bahir', 
	author_email='sanketbahir2016@gmail.com', 
	# packages=['sanketbahir'], 
	install_requires=[ 
	 
	], 
) 

